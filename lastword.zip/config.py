# -*- coding: utf-8 -*-
"""تنظیمات از Environment Variables (هیچ رازی داخل کد نیست).

نکته: نام‌ها با پیشوند LASTWORD_ هستند تا با ربات «منفی» (که BOT_TOKEN و PORT خودش را دارد)
در یک سرویس Render قاطی نشوند. عمداً به BOT_TOKEN برنمی‌گردیم: اگر توکن منفی به‌اشتباه
اینجا بیاید، دو برنامه با یک توکن همزمان پیام می‌گیرند و ربات منفی خراب می‌شود.
"""
import os


def _int(name, default=None):
    v = os.environ.get(name, "").strip()
    if not v:
        return default
    try:
        return int(v)
    except ValueError:
        raise SystemExit(f"متغیر {name} باید عدد باشد.")


BOT_TOKEN = os.environ.get("LASTWORD_BOT_TOKEN", "").strip()
OWNER_ID = _int("LASTWORD_OWNER_ID", 8659480577)
GROUP_CHAT_ID = _int("LASTWORD_GROUP_CHAT_ID")
DB_PATH = os.environ.get("LASTWORD_DB_PATH", "bot_data/last_word.db")
PORT = _int("LASTWORD_PORT", 10000)
# سرور سلامت (health) فقط وقتی لازم است که این ربات «تنها» روی یک Web Service باشد.
# داخل سرویس منفی، خود Node پورت را دارد و این باید 0 بماند.
HEALTH_SERVER = os.environ.get("LASTWORD_HEALTH", "0").strip() == "1"
